import { NextResponse } from "next/server";
import { supabaseAdmin, supabaseServer } from "./supabase/server";
import { subscribeToPresentationGuru } from "./mailchimp";

export type Profile = {
  id: string;
  email: string;
  plan: "free" | "pro";
  plan_source: "stripe" | "code" | "manual" | null;
  stripe_customer_id: string | null;
  stripe_subscription_id: string | null;
  subscription_status: string | null;
  current_period_end: string | null;
  cohort_code: string | null;
};

/** The signed-in user's profile, created on first sight. Null when nobody is signed in. */
export async function currentProfile(): Promise<Profile | null> {
  const sb = await supabaseServer();
  const { data } = await sb.auth.getUser();
  const user = data.user;
  if (!user || !user.email) return null;
  const admin = supabaseAdmin();
  const { data: existing } = await admin.from("profiles").select("*").eq("id", user.id).maybeSingle();
  if (existing) return existing as Profile;
  const { data: created, error } = await admin
    .from("profiles")
    .insert({ id: user.id, email: user.email })
    .select("*")
    .single();
  if (error) throw new Error(`Could not create profile: ${error.message}`);
  // First sign-in: join the Presentation Guru list. Never blocks the user.
  subscribeToPresentationGuru(user.email)
    .then((ok) => {
      if (ok) admin.from("profiles").update({ mailchimp_subscribed_at: new Date().toISOString() }).eq("id", user.id).then(() => {});
    })
    .catch((e) => console.warn("[mailchimp]", e instanceof Error ? e.message : e));
  return created as Profile;
}

/** Pro if the plan says so and, for Stripe or code plans, the period has not ended. */
export function isPro(p: Profile | null): boolean {
  if (!p || p.plan !== "pro") return false;
  if (p.current_period_end && new Date(p.current_period_end).getTime() < Date.now() - 3 * 86400000) return false;
  return true;
}

export function signInRequired() {
  return NextResponse.json({ error: "Sign in to use the Story Machine.", code: "signin" }, { status: 401 });
}

export function proRequired() {
  return NextResponse.json(
    { error: "Making it land is part of the paid Story Machine. Upgrade or enter a programme code.", code: "upgrade" },
    { status: 402 }
  );
}

export async function logGeneration(
  userId: string | null,
  kind: "story" | "land" | "edit" | "refine" | "extract",
  meta?: { attempts?: number; violationsBefore?: number; violationsAfter?: number }
) {
  try {
    await supabaseAdmin().from("generations").insert({
      user_id: userId,
      kind,
      attempts: meta?.attempts ?? null,
      violations_before: meta?.violationsBefore ?? null,
      violations_after: meta?.violationsAfter ?? null,
    });
  } catch (e) {
    console.warn("[generations]", e instanceof Error ? e.message : e);
  }
}
