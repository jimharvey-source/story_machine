"use client";

import { useState } from "react";
import { supabaseBrowser } from "@/lib/supabase/browser";

export type Me = {
  signedIn: boolean;
  email?: string;
  pro?: boolean;
  planSource?: "stripe" | "code" | "manual" | null;
  periodEnd?: string | null;
  cohortCode?: string | null;
  stripeCustomer?: boolean;
};

export function SignIn({ compact }: { compact?: boolean }) {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function send(e: React.FormEvent) {
    e.preventDefault();
    const v = email.trim();
    if (!v) return;
    setBusy(true);
    setError(null);
    try {
      const sb = supabaseBrowser();
      const { error } = await sb.auth.signInWithOtp({
        email: v,
        options: { emailRedirectTo: `${window.location.origin}/auth/callback` },
      });
      if (error) throw error;
      setSent(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not send the link");
    } finally {
      setBusy(false);
    }
  }

  if (sent) {
    return (
      <div className="rounded-md border border-rule bg-paper-2 p-5">
        <p className="eyebrow">Check your email</p>
        <p className="mt-2 text-ink">
          A sign-in link is on its way to <span className="font-medium">{email}</span>. Open it on this device and you
          come straight back here.
        </p>
        <p className="mt-2 text-sm text-muted">Nothing arrived after a minute? Look in spam, or send it again.</p>
        <button type="button" onClick={() => setSent(false)} className="mt-3 text-sm text-muted underline decoration-rule underline-offset-4 hover:text-ink">
          Send it again
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={send} className={compact ? "flex flex-wrap items-end gap-2" : "rounded-md border border-rule bg-paper-2 p-5"}>
      {!compact && (
        <>
          <p className="eyebrow">Sign in to find your story</p>
          <p className="mt-2 text-ink">
            Your first story is free. Enter your email and we send you a link. No password to remember.
          </p>
        </>
      )}
      <div className={compact ? "flex flex-wrap items-center gap-2" : "mt-4 flex flex-wrap items-center gap-2"}>
        <input
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="you@company.com"
          className="w-64 max-w-full rounded-md border border-rule bg-paper-2 px-3 py-2.5 text-base outline-none focus:border-ink"
        />
        <button type="submit" disabled={busy} className="rounded-md bg-ink px-4 py-2.5 text-base font-medium text-paper disabled:opacity-40">
          {busy ? "Sending..." : "Send me a link"}
        </button>
      </div>
      {!compact && (
        <p className="mt-3 text-xs text-muted">
          Signing in adds you to the Presentation Guru list, one email a month from Jim Harvey. Unsubscribe any time.
        </p>
      )}
      {error && <p className="mt-2 text-sm text-red">{error}</p>}
    </form>
  );
}

export function AccountBar({ me, onChange, onOpenStories }: { me: Me; onChange: () => void; onOpenStories: () => void }) {
  const [busy, setBusy] = useState<string | null>(null);
  const [code, setCode] = useState("");
  const [showCode, setShowCode] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  async function signOut() {
    setBusy("out");
    await fetch("/api/me", { method: "DELETE" });
    onChange();
    setBusy(null);
  }

  async function portal() {
    setBusy("portal");
    const res = await fetch("/api/portal", { method: "POST" });
    const data = await res.json();
    setBusy(null);
    if (data.url) window.location.href = data.url;
    else setMsg(data.error || "Could not open billing");
  }

  async function redeem(e: React.FormEvent) {
    e.preventDefault();
    setBusy("code");
    setMsg(null);
    const res = await fetch("/api/code", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ code }) });
    const data = await res.json();
    setBusy(null);
    if (res.ok) {
      setMsg(`Unlocked: ${data.label}`);
      setShowCode(false);
      onChange();
    } else setMsg(data.error || "That code did not work");
  }

  if (!me.signedIn) return null;
  return (
    <div className="mb-8 flex flex-wrap items-center gap-x-4 gap-y-2 border-b border-rule pb-4 font-mono text-[0.7rem] uppercase tracking-[0.12em] text-muted">
      <span className="normal-case tracking-normal font-body text-sm text-ink">{me.email}</span>
      <span className={me.pro ? "text-red" : ""}>{me.pro ? (me.planSource === "code" ? "Programme" : "Pro") : "Free"}</span>
      {me.pro && (
        <button type="button" onClick={onOpenStories} className="underline decoration-rule underline-offset-4 hover:text-ink">
          My stories
        </button>
      )}
      {me.pro && me.stripeCustomer && (
        <button type="button" onClick={portal} disabled={busy !== null} className="underline decoration-rule underline-offset-4 hover:text-ink">
          Billing
        </button>
      )}
      {!me.pro && (
        <button type="button" onClick={() => setShowCode((v) => !v)} className="underline decoration-rule underline-offset-4 hover:text-ink">
          Programme code
        </button>
      )}
      <button type="button" onClick={signOut} disabled={busy !== null} className="underline decoration-rule underline-offset-4 hover:text-ink">
        Sign out
      </button>
      {showCode && (
        <form onSubmit={redeem} className="flex w-full items-center gap-2 pt-1">
          <input
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            placeholder="CODE"
            className="w-40 rounded-md border border-rule bg-paper-2 px-3 py-1.5 font-mono text-sm tracking-[0.12em] text-ink outline-none focus:border-ink"
          />
          <button type="submit" disabled={busy !== null || !code.trim()} className="rounded-md bg-ink px-3 py-1.5 font-body text-sm normal-case tracking-normal text-paper disabled:opacity-40">
            Unlock
          </button>
        </form>
      )}
      {msg && <span className="w-full font-body text-sm normal-case tracking-normal text-ink">{msg}</span>}
    </div>
  );
}

export function Paywall({ me, onChange }: { me: Me; onChange: () => void }) {
  const [busy, setBusy] = useState<string | null>(null);
  const [code, setCode] = useState("");
  const [msg, setMsg] = useState<string | null>(null);

  async function checkout(plan: "monthly" | "yearly") {
    setBusy(plan);
    setMsg(null);
    const res = await fetch("/api/checkout", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ plan }) });
    const data = await res.json();
    setBusy(null);
    if (data.url) window.location.href = data.url;
    else setMsg(data.error || "Could not start checkout");
  }

  async function redeem(e: React.FormEvent) {
    e.preventDefault();
    setBusy("code");
    setMsg(null);
    const res = await fetch("/api/code", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ code }) });
    const data = await res.json();
    setBusy(null);
    if (res.ok) {
      setMsg(`Unlocked: ${data.label}`);
      onChange();
    } else setMsg(data.error || "That code did not work");
  }

  return (
    <section className="rounded-md border border-ink bg-paper-2 p-6 sm:p-8">
      <p className="eyebrow">Your story is straight. Now make it land.</p>
      <h2 className="display mt-2 text-2xl sm:text-3xl">The second half is the paid half.</h2>
      <p className="mt-3 max-w-xl text-ink-2">
        The Prologue that earns the room, a signpost and a slide for each act, an Epilogue that ends with certainty,
        the story in five lines, edits on every line, a strategist to argue with, document upload, saved stories and
        a PDF with a slide brief.
      </p>
      <div className="mt-5 flex flex-wrap gap-3">
        <button type="button" onClick={() => checkout("monthly")} disabled={busy !== null} className="rounded-md bg-ink px-5 py-3 text-base font-medium text-paper disabled:opacity-40">
          {busy === "monthly" ? "Opening checkout..." : "£12 a month"}
        </button>
        <button type="button" onClick={() => checkout("yearly")} disabled={busy !== null} className="rounded-md border border-ink bg-paper-2 px-5 py-3 text-base font-medium text-ink disabled:opacity-40">
          {busy === "yearly" ? "Opening checkout..." : "£96 a year"}
        </button>
      </div>
      <p className="mt-2 text-xs text-muted">Cancel any time from the billing page. Launch offer codes go in at checkout.</p>
      <form onSubmit={redeem} className="mt-5 flex flex-wrap items-center gap-2 border-t border-rule pt-4">
        <span className="text-sm text-muted">On a programme? Enter your programme code.</span>
        <input
          value={code}
          onChange={(e) => setCode(e.target.value.toUpperCase())}
          placeholder="CODE"
          className="w-36 rounded-md border border-rule bg-paper-2 px-3 py-1.5 font-mono text-sm tracking-[0.12em] outline-none focus:border-ink"
        />
        <button type="submit" disabled={busy !== null || !code.trim()} className="rounded-md border border-ink px-3 py-1.5 text-sm text-ink disabled:opacity-40">
          Unlock
        </button>
      </form>
      {msg && <p className="mt-3 text-sm text-ink">{msg}</p>}
      <p className="mt-4 text-xs text-muted">
        Signed in as {me.email}. The story above is yours to copy now.
      </p>
    </section>
  );
}
