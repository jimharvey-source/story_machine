import { NextResponse } from "next/server";
import { currentProfile, signInRequired } from "@/lib/access";
import { stripe } from "@/lib/stripe";
import { supabaseAdmin } from "@/lib/supabase/server";

export const runtime = "nodejs";

// Called on return from Stripe so the page shows Pro at once, before the webhook lands.
export async function POST(req: Request) {
  const p = await currentProfile();
  if (!p) return signInRequired();
  let sessionId = "";
  try {
    sessionId = String((await req.json()).sessionId ?? "");
  } catch {
    return NextResponse.json({ error: "Missing session" }, { status: 400 });
  }
  try {
    const session = await stripe().checkout.sessions.retrieve(sessionId, { expand: ["subscription"] });
    if (session.metadata?.user_id !== p.id) return NextResponse.json({ error: "That checkout is not yours" }, { status: 403 });
    const sub = session.subscription;
    if (!sub || typeof sub === "string") return NextResponse.json({ ok: false });
    const active = sub.status === "active" || sub.status === "trialing";
    if (active) {
      const item = sub.items.data[0];
      await supabaseAdmin()
        .from("profiles")
        .update({
          plan: "pro",
          plan_source: "stripe",
          stripe_subscription_id: sub.id,
          subscription_status: sub.status,
          current_period_end: item?.current_period_end ? new Date(item.current_period_end * 1000).toISOString() : null,
          updated_at: new Date().toISOString(),
        })
        .eq("id", p.id);
    }
    return NextResponse.json({ ok: active });
  } catch (e) {
    const message = e instanceof Error ? e.message : "Unknown error";
    console.error("[api/checkout/verify]", message);
    return NextResponse.json({ error: message }, { status: 502 });
  }
}
