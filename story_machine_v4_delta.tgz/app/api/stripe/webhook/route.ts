import { NextResponse } from "next/server";
import type Stripe from "stripe";
import { stripe } from "@/lib/stripe";
import { supabaseAdmin } from "@/lib/supabase/server";

export const runtime = "nodejs";

// Keeps profiles in step with Stripe: created, renewed, cancelled, payment failed.
// Configure the endpoint in Stripe at /api/stripe/webhook and set STRIPE_WEBHOOK_SECRET.

async function applySubscription(sub: Stripe.Subscription) {
  const admin = supabaseAdmin();
  const customer = typeof sub.customer === "string" ? sub.customer : sub.customer.id;
  const item = sub.items.data[0];
  const periodEnd = item?.current_period_end ? new Date(item.current_period_end * 1000).toISOString() : null;
  const active = sub.status === "active" || sub.status === "trialing" || sub.status === "past_due";
  const { data: profile } = await admin.from("profiles").select("id, plan_source").eq("stripe_customer_id", customer).maybeSingle();
  if (!profile) {
    console.warn("[webhook] no profile for customer", customer);
    return;
  }
  const update: Record<string, unknown> = {
    stripe_subscription_id: sub.id,
    subscription_status: sub.status,
    current_period_end: periodEnd,
    updated_at: new Date().toISOString(),
  };
  if (active) {
    update.plan = "pro";
    update.plan_source = "stripe";
  } else if (profile.plan_source === "stripe" || profile.plan_source === null) {
    update.plan = "free";
  }
  await admin.from("profiles").update(update).eq("id", profile.id);
}

export async function POST(req: Request) {
  const secret = (process.env.STRIPE_WEBHOOK_SECRET ?? "").trim();
  if (!secret) return NextResponse.json({ error: "STRIPE_WEBHOOK_SECRET is not set" }, { status: 500 });
  const sig = req.headers.get("stripe-signature") ?? "";
  const raw = await req.text();
  let event: Stripe.Event;
  try {
    event = stripe().webhooks.constructEvent(raw, sig, secret);
  } catch (e) {
    const message = e instanceof Error ? e.message : "bad signature";
    return NextResponse.json({ error: message }, { status: 400 });
  }
  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object;
        if (session.mode === "subscription" && session.subscription) {
          const sub = await stripe().subscriptions.retrieve(String(session.subscription));
          await applySubscription(sub);
        }
        break;
      }
      case "customer.subscription.created":
      case "customer.subscription.updated":
      case "customer.subscription.deleted":
        await applySubscription(event.data.object);
        break;
      default:
        break;
    }
  } catch (e) {
    console.error("[webhook]", event.type, e instanceof Error ? e.message : e);
    return NextResponse.json({ error: "handler failed" }, { status: 500 });
  }
  return NextResponse.json({ received: true });
}
